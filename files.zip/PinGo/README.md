# PinGo — Android source project

Two ways to find location details:
- **Use My Location** — asks for GPS permission, uses your current position
- **Type a place name** — no GPS needed, searches by the name you type

Shows (each section only appears if data was actually found — no "N/A"):
1. Area
2. District
3. State
4. Country
5. Nearest ATMs (up to 5, with distance)
6. Nearest Railway Station (up to 2, with distance)
7. Nearest Airport (with distance)
8. Nearest Famous Area (up to 4, with distance)
9. Nearest Police Station (with distance)
10. Nearest Shopping Market/Mall (up to 3, with distance)
11. Nearest Bus Stand (up to 4, with distance)
12. "Open in Maps" button

## A note on "Police Station Jurisdiction"

There's no free, public dataset anywhere that maps exact police jurisdiction
boundaries to a location — that data isn't openly published by any police
department or open-map project. This shows the **nearest police station**
(name + distance) instead, which is genuinely available.

## How blanks are minimized (all using free, no-signup tools)

All data comes from OpenStreetMap, via two free services:
- **Nominatim** — address details (area/district/state/country)
- **Overpass API** — nearest ATMs, stations, airports, etc.

To cut down on "nothing found" results, each category:
- Searches **multiple related tags** at once (e.g. ATMs also match banks;
  bus stands also match major bus stops; shopping also matches malls,
  supermarkets, and marketplaces)
- **Automatically widens the search radius** if nothing turns up nearby,
  before giving up

This means a search can occasionally take 15–30 seconds in areas where the
first radius comes up empty for several categories — that's the tradeoff
for trying harder before showing nothing. If a category is still empty
after the widest radius, its whole heading is hidden rather than showing
"N/A" or "Not found."

## Building the APK (same GitHub Actions routine as your other apps)

1. Zip this whole `PinGo` folder.
2. Create a new GitHub repo, upload the zip as `files.zip`.
3. Add `.github/workflows/build.yml` (provided alongside this project).
4. Push → **Actions** tab → wait for ✅ → download from **Artifacts** →
   extract → install `app-debug.apk`.

This project already includes a fixed debug keystore, so future rebuilds
keep the same signature and install directly over old versions.

## Permissions

Only asked for when you tap "Use My Location": fine + coarse location. The
"type a place name" option needs no permissions at all.
