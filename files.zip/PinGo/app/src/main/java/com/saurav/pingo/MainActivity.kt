package com.saurav.pingo

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.location.LocationServices
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

class MainActivity : AppCompatActivity() {

    private lateinit var btnUseLocation: Button
    private lateinit var etPlaceName: EditText
    private lateinit var btnSearchPlace: Button
    private lateinit var progressBar: ProgressBar
    private lateinit var tvStatus: TextView
    private lateinit var resultCard: androidx.cardview.widget.CardView
    private lateinit var btnOpenMaps: Button

    private lateinit var rowArea: View
    private lateinit var rowDistrict: View
    private lateinit var rowState: View
    private lateinit var rowCountry: View
    private lateinit var rowAtm: View
    private lateinit var rowRailway: View
    private lateinit var rowAirport: View
    private lateinit var rowFamousArea: View
    private lateinit var rowPolice: View
    private lateinit var rowShopping: View
    private lateinit var rowBusStand: View

    private lateinit var tvArea: TextView
    private lateinit var tvDistrict: TextView
    private lateinit var tvState: TextView
    private lateinit var tvCountry: TextView
    private lateinit var tvAtm: TextView
    private lateinit var tvRailway: TextView
    private lateinit var tvAirport: TextView
    private lateinit var tvFamousArea: TextView
    private lateinit var tvPolice: TextView
    private lateinit var tvShopping: TextView
    private lateinit var tvBusStand: TextView

    private var currentLat: Double = 0.0
    private var currentLon: Double = 0.0

    private val locationPermissionRequestCode = 100

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btnUseLocation = findViewById(R.id.btnUseLocation)
        etPlaceName = findViewById(R.id.etPlaceName)
        btnSearchPlace = findViewById(R.id.btnSearchPlace)
        progressBar = findViewById(R.id.progressBar)
        tvStatus = findViewById(R.id.tvStatus)
        resultCard = findViewById(R.id.resultCard)
        btnOpenMaps = findViewById(R.id.btnOpenMaps)

        rowArea = findViewById(R.id.rowArea)
        rowDistrict = findViewById(R.id.rowDistrict)
        rowState = findViewById(R.id.rowState)
        rowCountry = findViewById(R.id.rowCountry)
        rowAtm = findViewById(R.id.rowAtm)
        rowRailway = findViewById(R.id.rowRailway)
        rowAirport = findViewById(R.id.rowAirport)
        rowFamousArea = findViewById(R.id.rowFamousArea)
        rowPolice = findViewById(R.id.rowPolice)
        rowShopping = findViewById(R.id.rowShopping)
        rowBusStand = findViewById(R.id.rowBusStand)

        tvArea = findViewById(R.id.tvArea)
        tvDistrict = findViewById(R.id.tvDistrict)
        tvState = findViewById(R.id.tvState)
        tvCountry = findViewById(R.id.tvCountry)
        tvAtm = findViewById(R.id.tvAtm)
        tvRailway = findViewById(R.id.tvRailway)
        tvAirport = findViewById(R.id.tvAirport)
        tvFamousArea = findViewById(R.id.tvFamousArea)
        tvPolice = findViewById(R.id.tvPolice)
        tvShopping = findViewById(R.id.tvShopping)
        tvBusStand = findViewById(R.id.tvBusStand)

        btnUseLocation.setOnClickListener { checkPermissionAndFetch() }
        btnOpenMaps.setOnClickListener { openInMaps() }

        btnSearchPlace.setOnClickListener { searchTypedPlace() }
        etPlaceName.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                searchTypedPlace()
                true
            } else {
                false
            }
        }
    }

    private fun checkPermissionAndFetch() {
        val hasPermission = ContextCompat.checkSelfPermission(
            this, Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED

        if (hasPermission) {
            fetchGpsLocation()
        } else {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION),
                locationPermissionRequestCode
            )
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == locationPermissionRequestCode) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                fetchGpsLocation()
            } else {
                Toast.makeText(this, getString(R.string.permission_needed), Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun fetchGpsLocation() {
        resultCard.visibility = View.GONE
        progressBar.visibility = View.VISIBLE
        tvStatus.text = getString(R.string.fetching)

        val hasPermission = ContextCompat.checkSelfPermission(
            this, Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        if (!hasPermission) return

        val client = LocationServices.getFusedLocationProviderClient(this)
        client.lastLocation
            .addOnSuccessListener { location ->
                if (location != null) {
                    currentLat = location.latitude
                    currentLon = location.longitude
                    loadAllDetails(currentLat, currentLon)
                } else {
                    progressBar.visibility = View.GONE
                    tvStatus.text = "Couldn't get a location fix. Make sure GPS is turned on and try again."
                }
            }
            .addOnFailureListener {
                progressBar.visibility = View.GONE
                tvStatus.text = "Failed to get location: ${it.message}"
            }
    }

    private fun searchTypedPlace() {
        val placeName = etPlaceName.text.toString().trim()
        if (placeName.isBlank()) {
            Toast.makeText(this, "Type a place name first", Toast.LENGTH_SHORT).show()
            return
        }

        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(etPlaceName.windowToken, 0)

        resultCard.visibility = View.GONE
        progressBar.visibility = View.VISIBLE
        tvStatus.text = getString(R.string.fetching)

        Thread {
            var foundLat: Double? = null
            var foundLon: Double? = null
            try {
                val encoded = URLEncoder.encode(placeName, "UTF-8")
                val url = URL("https://nominatim.openstreetmap.org/search?q=$encoded&format=json&limit=1")
                val conn = url.openConnection() as HttpURLConnection
                conn.setRequestProperty("User-Agent", "PinGoApp/1.0")
                conn.connectTimeout = 10000
                conn.readTimeout = 10000
                if (conn.responseCode == 200) {
                    val body = conn.inputStream.bufferedReader().use { it.readText() }
                    val arr = JSONArray(body)
                    if (arr.length() > 0) {
                        val first = arr.getJSONObject(0)
                        foundLat = first.optString("lat").toDoubleOrNull()
                        foundLon = first.optString("lon").toDoubleOrNull()
                    }
                }
                conn.disconnect()
            } catch (e: Exception) {
                // handled below via null check
            }

            runOnUiThread {
                if (foundLat != null && foundLon != null) {
                    currentLat = foundLat
                    currentLon = foundLon
                    loadAllDetails(currentLat, currentLon)
                } else {
                    progressBar.visibility = View.GONE
                    tvStatus.text = "Couldn't find that place. Try a more specific name (e.g. add city/state)."
                }
            }
        }.start()
    }

    private fun loadAllDetails(lat: Double, lon: Double) {
        Thread {
            var area: String? = null
            var district: String? = null
            var state: String? = null
            var country: String? = null

            try {
                val url = URL(
                    "https://nominatim.openstreetmap.org/reverse?format=json&lat=$lat&lon=$lon&zoom=16&addressdetails=1"
                )
                val conn = url.openConnection() as HttpURLConnection
                conn.setRequestProperty("User-Agent", "PinGoApp/1.0")
                conn.connectTimeout = 10000
                conn.readTimeout = 10000
                if (conn.responseCode == 200) {
                    val body = conn.inputStream.bufferedReader().use { it.readText() }
                    val json = JSONObject(body)
                    val addr = json.optJSONObject("address")
                    if (addr != null) {
                        area = firstNonBlankOrNull(
                            addr.optString("suburb"), addr.optString("neighbourhood"),
                            addr.optString("quarter"), addr.optString("village"),
                            addr.optString("town"), addr.optString("city")
                        )
                        district = firstNonBlankOrNull(
                            addr.optString("city_district"), addr.optString("state_district"),
                            addr.optString("county"), addr.optString("district")
                        )
                        val isoCode = json.optString("ISO3166-2-lvl4", "")
                        state = firstNonBlankOrNull(addr.optString("state")) ?: IndiaStateLookup.nameForIsoCode(isoCode)
                        country = addr.optString("country", "").ifBlank { null }
                    }
                }
                conn.disconnect()
            } catch (e: Exception) {
                // leave these null - the section will just be hidden
            }

            val atmResults = findNearbyPlaces(
                lat, lon,
                listOf("[\"amenity\"=\"atm\"]", "[\"amenity\"=\"bank\"]"),
                listOf(3000, 10000, 30000), topN = 5
            )
            val railwayResults = findNearbyPlaces(
                lat, lon,
                listOf("[\"railway\"=\"station\"]", "[\"railway\"=\"halt\"]"),
                listOf(15000, 40000, 100000), topN = 2
            )
            val airportResults = findNearbyPlaces(
                lat, lon,
                listOf("[\"aeroway\"=\"aerodrome\"]"),
                listOf(100000, 300000), topN = 1
            )
            val famousAreaResults = findNearbyPlaces(
                lat, lon,
                listOf("[\"place\"~\"^(city|town)$\"]"),
                listOf(30000, 80000, 150000), topN = 4
            )
            val policeResults = findNearbyPlaces(
                lat, lon,
                listOf("[\"amenity\"=\"police\"]"),
                listOf(10000, 30000, 80000), topN = 1
            )
            val shoppingResults = findNearbyPlaces(
                lat, lon,
                listOf("[\"shop\"=\"mall\"]", "[\"shop\"=\"supermarket\"]", "[\"amenity\"=\"marketplace\"]"),
                listOf(5000, 15000, 40000), topN = 3
            )
            val busStandResults = findNearbyPlaces(
                lat, lon,
                listOf("[\"amenity\"=\"bus_station\"]", "[\"highway\"=\"bus_stop\"]"),
                listOf(5000, 20000, 60000), topN = 4
            )

            val finalArea = area; val finalDistrict = district; val finalState = state; val finalCountry = country

            runOnUiThread {
                progressBar.visibility = View.GONE
                tvStatus.text = ""

                setRowOrHide(rowArea, tvArea, finalArea)
                setRowOrHide(rowDistrict, tvDistrict, finalDistrict)
                setRowOrHide(rowState, tvState, finalState)
                setRowOrHide(rowCountry, tvCountry, finalCountry)

                setRowOrHide(rowAtm, tvAtm, formatResults(atmResults))
                setRowOrHide(rowRailway, tvRailway, formatResults(railwayResults))
                setRowOrHide(rowAirport, tvAirport, formatResults(airportResults))
                setRowOrHide(rowFamousArea, tvFamousArea, formatResults(famousAreaResults))
                setRowOrHide(rowPolice, tvPolice, formatResults(policeResults))
                setRowOrHide(rowShopping, tvShopping, formatResults(shoppingResults))
                setRowOrHide(rowBusStand, tvBusStand, formatResults(busStandResults))

                resultCard.visibility = View.VISIBLE
            }
        }.start()
    }

    private fun setRowOrHide(row: View, valueView: TextView, value: String?) {
        if (value.isNullOrBlank()) {
            row.visibility = View.GONE
        } else {
            row.visibility = View.VISIBLE
            valueView.text = value
        }
    }

    private fun formatResults(results: List<Pair<String, Double>>): String? {
        if (results.isEmpty()) return null
        return results.joinToString("\n") { (name, km) -> "$name (${String.format("%.1f", km)} km)" }
    }

    private fun firstNonBlankOrNull(vararg values: String?): String? {
        for (v in values) {
            if (!v.isNullOrBlank()) return v
        }
        return null
    }

    private fun findNearbyPlaces(
        lat: Double, lon: Double,
        tagFilters: List<String>,
        radiiMeters: List<Int>,
        topN: Int
    ): List<Pair<String, Double>> {
        for (radius in radiiMeters) {
            val results = queryOverpass(lat, lon, tagFilters, radius, topN)
            if (results.isNotEmpty()) return results
        }
        return emptyList()
    }

    private fun queryOverpass(
        lat: Double, lon: Double,
        tagFilters: List<String>,
        radiusMeters: Int,
        topN: Int
    ): List<Pair<String, Double>> {
        return try {
            val clauses = StringBuilder()
            for (filter in tagFilters) {
                clauses.append("node$filter(around:$radiusMeters,$lat,$lon);")
                clauses.append("way$filter(around:$radiusMeters,$lat,$lon);")
                clauses.append("relation$filter(around:$radiusMeters,$lat,$lon);")
            }
            val query = "[out:json][timeout:20];($clauses);out center 40;"
            val encodedQuery = URLEncoder.encode(query, "UTF-8")
            val url = URL("https://overpass-api.de/api/interpreter?data=$encodedQuery")
            val conn = url.openConnection() as HttpURLConnection
            conn.requestMethod = "GET"
            conn.connectTimeout = 18000
            conn.readTimeout = 18000

            if (conn.responseCode != 200) {
                conn.disconnect()
                return emptyList()
            }

            val body = conn.inputStream.bufferedReader().use { it.readText() }
            conn.disconnect()

            val json = JSONObject(body)
            val elements = json.optJSONArray("elements") ?: JSONArray()

            val found = mutableListOf<Pair<String, Double>>()

            for (i in 0 until elements.length()) {
                val el = elements.getJSONObject(i)
                val tags = el.optJSONObject("tags")
                val name = tags?.optString("name", "")?.takeIf { it.isNotBlank() } ?: continue

                var elLat = el.optDouble("lat", Double.NaN)
                var elLon = el.optDouble("lon", Double.NaN)
                if (elLat.isNaN() || elLon.isNaN()) {
                    val center = el.optJSONObject("center")
                    if (center != null) {
                        elLat = center.optDouble("lat", Double.NaN)
                        elLon = center.optDouble("lon", Double.NaN)
                    }
                }
                if (elLat.isNaN() || elLon.isNaN()) continue

                val distanceKm = haversineKm(lat, lon, elLat, elLon)
                found.add(name to distanceKm)
            }

            found
                .groupBy { it.first }
                .map { (name, entries) -> name to entries.minOf { it.second } }
                .sortedBy { it.second }
                .take(topN)
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun haversineKm(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val r = 6371.0
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = sin(dLat / 2) * sin(dLat / 2) +
                cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) *
                sin(dLon / 2) * sin(dLon / 2)
        val c = 2 * atan2(sqrt(a), sqrt(1 - a))
        return r * c
    }

    private fun openInMaps() {
        if (currentLat == 0.0 && currentLon == 0.0) {
            Toast.makeText(this, "Get a location first", Toast.LENGTH_SHORT).show()
            return
        }
        val uri = Uri.parse("geo:$currentLat,$currentLon?q=$currentLat,$currentLon")
        val intent = Intent(Intent.ACTION_VIEW, uri)
        try {
            startActivity(intent)
        } catch (e: Exception) {
            val browserUri = Uri.parse("https://www.google.com/maps?q=$currentLat,$currentLon")
            startActivity(Intent(Intent.ACTION_VIEW, browserUri))
        }
    }
}
